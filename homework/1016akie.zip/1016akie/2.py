text = input()
text_find = input()
count = text.count(text_find)
print(count)
