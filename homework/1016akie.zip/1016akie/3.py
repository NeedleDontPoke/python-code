input_str = input()
input_list = input_str.split()
name = input_list[0]
n = int(input_list[1])
print(name + '我爱你' * n)
